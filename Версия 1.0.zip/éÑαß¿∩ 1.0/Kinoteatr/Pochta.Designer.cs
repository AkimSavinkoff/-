﻿namespace Kinoteatr
{
    partial class Pochta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_Opis = new System.Windows.Forms.TextBox();
            this.comboBox_Tema = new System.Windows.Forms.ComboBox();
            this.label_Tema = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label_Obrat = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // textBox_Opis
            // 
            this.textBox_Opis.Location = new System.Drawing.Point(28, 125);
            this.textBox_Opis.Multiline = true;
            this.textBox_Opis.Name = "textBox_Opis";
            this.textBox_Opis.Size = new System.Drawing.Size(594, 227);
            this.textBox_Opis.TabIndex = 28;
            // 
            // comboBox_Tema
            // 
            this.comboBox_Tema.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_Tema.FormattingEnabled = true;
            this.comboBox_Tema.Items.AddRange(new object[] {
            "Ошибка",
            "Предложение",
            "Отзыв"});
            this.comboBox_Tema.Location = new System.Drawing.Point(361, 75);
            this.comboBox_Tema.Name = "comboBox_Tema";
            this.comboBox_Tema.Size = new System.Drawing.Size(202, 33);
            this.comboBox_Tema.TabIndex = 24;
            // 
            // label_Tema
            // 
            this.label_Tema.AutoSize = true;
            this.label_Tema.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_Tema.Location = new System.Drawing.Point(383, 52);
            this.label_Tema.Name = "label_Tema";
            this.label_Tema.Size = new System.Drawing.Size(51, 20);
            this.label_Tema.TabIndex = 23;
            this.label_Tema.Text = "Тема";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(267, 125);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 20);
            this.label4.TabIndex = 22;
            this.label4.Text = "Описание ";
            // 
            // button2
            // 
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(373, 373);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(237, 70);
            this.button2.TabIndex = 21;
            this.button2.Text = "Отменить";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(40, 373);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(237, 70);
            this.button1.TabIndex = 20;
            this.button1.Text = "Отправить";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_Obrat
            // 
            this.label_Obrat.AutoSize = true;
            this.label_Obrat.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label_Obrat.Location = new System.Drawing.Point(205, 5);
            this.label_Obrat.Name = "label_Obrat";
            this.label_Obrat.Size = new System.Drawing.Size(269, 39);
            this.label_Obrat.TabIndex = 19;
            this.label_Obrat.Text = "Обратная связь";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBox1.Location = new System.Drawing.Point(28, 78);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(202, 30);
            this.textBox1.TabIndex = 32;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(36, 52);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(166, 20);
            this.label5.TabIndex = 33;
            this.label5.Text = "Имя пользователя";
            // 
            // Pochta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(654, 455);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.textBox_Opis);
            this.Controls.Add(this.comboBox_Tema);
            this.Controls.Add(this.label_Tema);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label_Obrat);
            this.Name = "Pochta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Обратная связь";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBox_Opis;
        private System.Windows.Forms.ComboBox comboBox_Tema;
        private System.Windows.Forms.Label label_Tema;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label_Obrat;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label5;
    }
}