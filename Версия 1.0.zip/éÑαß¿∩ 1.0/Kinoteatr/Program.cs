﻿using System;
using System.Windows.Forms;

namespace Kinoteatr
{
    static class Program
    {
        public static int Dolj_Id;
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form_Zastavka());
        }
    }
}
