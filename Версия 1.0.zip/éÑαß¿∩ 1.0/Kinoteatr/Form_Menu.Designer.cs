﻿namespace Kinoteatr
{
    partial class Form_Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.прцоессыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.афишаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.фильмыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.добавитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.удалитьФильмToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отделКадровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сотрудникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.принятиеНаРаботуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.увольнениеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.изменениеДолжностиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.должностиToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.работаСКлиентамиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.билетыToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.оформлениеПродажиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.почтаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.проверкаПрограммToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.micorosftOfficeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.microsoftWordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.прцоессыToolStripMenuItem,
            this.выходToolStripMenuItem,
            this.почтаToolStripMenuItem,
            this.проверкаПрограммToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 28);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // прцоессыToolStripMenuItem
            // 
            this.прцоессыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.афишаToolStripMenuItem,
            this.отделКадровToolStripMenuItem,
            this.работаСКлиентамиToolStripMenuItem});
            this.прцоессыToolStripMenuItem.Name = "прцоессыToolStripMenuItem";
            this.прцоессыToolStripMenuItem.Size = new System.Drawing.Size(94, 24);
            this.прцоессыToolStripMenuItem.Text = "Процессы";
            // 
            // афишаToolStripMenuItem
            // 
            this.афишаToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.фильмыToolStripMenuItem,
            this.добавитьToolStripMenuItem,
            this.удалитьФильмToolStripMenuItem});
            this.афишаToolStripMenuItem.Name = "афишаToolStripMenuItem";
            this.афишаToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.афишаToolStripMenuItem.Text = "Афиша";
            // 
            // фильмыToolStripMenuItem
            // 
            this.фильмыToolStripMenuItem.Name = "фильмыToolStripMenuItem";
            this.фильмыToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.фильмыToolStripMenuItem.Text = "Фильмы";
            this.фильмыToolStripMenuItem.Click += new System.EventHandler(this.фильмыToolStripMenuItem_Click);
            // 
            // добавитьToolStripMenuItem
            // 
            this.добавитьToolStripMenuItem.Name = "добавитьToolStripMenuItem";
            this.добавитьToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.добавитьToolStripMenuItem.Text = "Новый фильм";
            this.добавитьToolStripMenuItem.Click += new System.EventHandler(this.добавитьToolStripMenuItem_Click);
            // 
            // удалитьФильмToolStripMenuItem
            // 
            this.удалитьФильмToolStripMenuItem.Name = "удалитьФильмToolStripMenuItem";
            this.удалитьФильмToolStripMenuItem.Size = new System.Drawing.Size(198, 26);
            this.удалитьФильмToolStripMenuItem.Text = "Удалить фильм";
            this.удалитьФильмToolStripMenuItem.Click += new System.EventHandler(this.удалитьФильмToolStripMenuItem_Click);
            // 
            // отделКадровToolStripMenuItem
            // 
            this.отделКадровToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сотрудникиToolStripMenuItem,
            this.принятиеНаРаботуToolStripMenuItem,
            this.увольнениеToolStripMenuItem,
            this.изменениеДолжностиToolStripMenuItem,
            this.должностиToolStripMenuItem1});
            this.отделКадровToolStripMenuItem.Name = "отделКадровToolStripMenuItem";
            this.отделКадровToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.отделКадровToolStripMenuItem.Text = "Отдел кадров";
            // 
            // сотрудникиToolStripMenuItem
            // 
            this.сотрудникиToolStripMenuItem.Name = "сотрудникиToolStripMenuItem";
            this.сотрудникиToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.сотрудникиToolStripMenuItem.Text = "Сотрудники";
            this.сотрудникиToolStripMenuItem.Click += new System.EventHandler(this.сотрудникиToolStripMenuItem_Click);
            // 
            // принятиеНаРаботуToolStripMenuItem
            // 
            this.принятиеНаРаботуToolStripMenuItem.Name = "принятиеНаРаботуToolStripMenuItem";
            this.принятиеНаРаботуToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.принятиеНаРаботуToolStripMenuItem.Text = "Принятие на работу";
            this.принятиеНаРаботуToolStripMenuItem.Click += new System.EventHandler(this.принятиеНаРаботуToolStripMenuItem_Click);
            // 
            // увольнениеToolStripMenuItem
            // 
            this.увольнениеToolStripMenuItem.Name = "увольнениеToolStripMenuItem";
            this.увольнениеToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.увольнениеToolStripMenuItem.Text = "Увольнение";
            this.увольнениеToolStripMenuItem.Click += new System.EventHandler(this.увольнениеToolStripMenuItem_Click);
            // 
            // изменениеДолжностиToolStripMenuItem
            // 
            this.изменениеДолжностиToolStripMenuItem.Name = "изменениеДолжностиToolStripMenuItem";
            this.изменениеДолжностиToolStripMenuItem.Size = new System.Drawing.Size(252, 26);
            this.изменениеДолжностиToolStripMenuItem.Text = "Изменение должности";
            this.изменениеДолжностиToolStripMenuItem.Click += new System.EventHandler(this.изменениеДолжностиToolStripMenuItem_Click);
            // 
            // должностиToolStripMenuItem1
            // 
            this.должностиToolStripMenuItem1.Name = "должностиToolStripMenuItem1";
            this.должностиToolStripMenuItem1.Size = new System.Drawing.Size(252, 26);
            this.должностиToolStripMenuItem1.Text = "Должности";
            this.должностиToolStripMenuItem1.Click += new System.EventHandler(this.должностиToolStripMenuItem1_Click);
            // 
            // работаСКлиентамиToolStripMenuItem
            // 
            this.работаСКлиентамиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.клиентыToolStripMenuItem,
            this.билетыToolStripMenuItem1,
            this.оформлениеПродажиToolStripMenuItem});
            this.работаСКлиентамиToolStripMenuItem.Name = "работаСКлиентамиToolStripMenuItem";
            this.работаСКлиентамиToolStripMenuItem.Size = new System.Drawing.Size(230, 26);
            this.работаСКлиентамиToolStripMenuItem.Text = "Работа с клиентами";
            // 
            // клиентыToolStripMenuItem
            // 
            this.клиентыToolStripMenuItem.Name = "клиентыToolStripMenuItem";
            this.клиентыToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.клиентыToolStripMenuItem.Text = "Клиенты";
            this.клиентыToolStripMenuItem.Click += new System.EventHandler(this.клиентыToolStripMenuItem_Click);
            // 
            // билетыToolStripMenuItem1
            // 
            this.билетыToolStripMenuItem1.Name = "билетыToolStripMenuItem1";
            this.билетыToolStripMenuItem1.Size = new System.Drawing.Size(251, 26);
            this.билетыToolStripMenuItem1.Text = "Проданные билеты";
            this.билетыToolStripMenuItem1.Click += new System.EventHandler(this.билетыToolStripMenuItem1_Click);
            // 
            // оформлениеПродажиToolStripMenuItem
            // 
            this.оформлениеПродажиToolStripMenuItem.Name = "оформлениеПродажиToolStripMenuItem";
            this.оформлениеПродажиToolStripMenuItem.Size = new System.Drawing.Size(251, 26);
            this.оформлениеПродажиToolStripMenuItem.Text = "Оформление продажи";
            this.оформлениеПродажиToolStripMenuItem.Click += new System.EventHandler(this.оформлениеПродажиToolStripMenuItem_Click);
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(67, 24);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // почтаToolStripMenuItem
            // 
            this.почтаToolStripMenuItem.Name = "почтаToolStripMenuItem";
            this.почтаToolStripMenuItem.Size = new System.Drawing.Size(65, 24);
            this.почтаToolStripMenuItem.Text = "Почта";
            this.почтаToolStripMenuItem.Click += new System.EventHandler(this.почтаToolStripMenuItem_Click);
            // 
            // проверкаПрограммToolStripMenuItem
            // 
            this.проверкаПрограммToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.micorosftOfficeToolStripMenuItem,
            this.microsoftWordToolStripMenuItem});
            this.проверкаПрограммToolStripMenuItem.Name = "проверкаПрограммToolStripMenuItem";
            this.проверкаПрограммToolStripMenuItem.Size = new System.Drawing.Size(168, 24);
            this.проверкаПрограммToolStripMenuItem.Text = "Проверка программ";
            // 
            // micorosftOfficeToolStripMenuItem
            // 
            this.micorosftOfficeToolStripMenuItem.Name = "micorosftOfficeToolStripMenuItem";
            this.micorosftOfficeToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.micorosftOfficeToolStripMenuItem.Text = "Micorosft Excel";
            this.micorosftOfficeToolStripMenuItem.Click += new System.EventHandler(this.micorosftOfficeToolStripMenuItem_Click);
            // 
            // microsoftWordToolStripMenuItem
            // 
            this.microsoftWordToolStripMenuItem.Name = "microsoftWordToolStripMenuItem";
            this.microsoftWordToolStripMenuItem.Size = new System.Drawing.Size(224, 26);
            this.microsoftWordToolStripMenuItem.Text = "Microsoft Word";
            this.microsoftWordToolStripMenuItem.Click += new System.EventHandler(this.microsoftWordToolStripMenuItem_Click);
            // 
            // Form_Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.Name = "Form_Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Кинотеатр \"Главное меню\"";
            this.Load += new System.EventHandler(this.Form_Menu_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem прцоессыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отделКадровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сотрудникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem принятиеНаРаботуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem увольнениеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem изменениеДолжностиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem афишаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem фильмыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem работаСКлиентамиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem билетыToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem оформлениеПродажиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem добавитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem удалитьФильмToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem должностиToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem почтаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem проверкаПрограммToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem micorosftOfficeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem microsoftWordToolStripMenuItem;
    }
}